import numpy as np
import depthai as dai

def decode(data: dai.NNData) -> np.ndarray:
    # No need for any postprocessing, just a vector used for re-id
    return data.getData()
