.. raw:: html

    <h2>Got questions?</h2>

We're always happy to help with development or other questions you might have.

.. raw:: html

     <div class="cta-row cta-row-short">
         <div class="cta-box">
            <a href="https://luxonis.com/discord">
               <img src="/_images/discord.png" alt="Discord"/>
               <h5 class="cta-title">Community Discord</h5>
            </a>
         </div>
         <div class="cta-box">
            <a href="https://discuss.luxonis.com/">
               <img src="/_images/forum.png" alt="forum"/>
               <h5 class="cta-title">Discussion Forum</h5>
            </a>
         </div>
         <div class="cta-box">
            <a href="mailto:support@luxonis.com">
               <img src="/_images/email.png" alt="forum"/>
               <h5 class="cta-title">Email</h5>
            </a>
         </div>
      </div>
