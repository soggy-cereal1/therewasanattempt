To install this package, run the following command in your terminal window

.. code-block:: bash

   python3 -m pip install depthai-sdk
