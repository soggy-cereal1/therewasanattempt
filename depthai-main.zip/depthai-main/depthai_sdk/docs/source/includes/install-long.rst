.. include:: /includes/install-short.rst

.. note::

   If you're using Raspberry Pi, providing a Pi Wheels extra package url can significantly speed up the installation process by providing prebuilt binaries for OpenCV: ``python3 -m pip install --extra-index-url https://www.piwheels.org/simple/ depthai-sdk``
