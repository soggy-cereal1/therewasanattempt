def onNewFrame(frame, source):
    pass


def onShowFrame(frame, source):
    pass


def onNn(nn_packet, decoded_data):
    pass


def onReport(report):
    pass


def onSetup(*args, **kwargs):
    pass


def onTeardown(*args, **kwargs):
    pass


def onIter(*args, **kwargs):
    pass
